# covid_summarization
kaggle project, summarization over the CORD-19 datasets related to covid-19
